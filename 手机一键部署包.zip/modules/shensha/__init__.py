# -*- coding: utf-8 -*-
"""
================================================================================
神煞模块包
================================================================================
根据事项类型返回相应的神煞检查器

使用方法:
    1. 作为模块导入: from modules.shensha import get_checker
    2. 直接运行: python -m modules.shensha
================================================================================
"""

import sys
import os

# 检查是否是直接运行（不是作为模块导入）
if __name__ == '__main__' and __package__ is None:
    # 添加项目根目录到路径
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    # 添加 modules 目录到路径
    modules_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if modules_dir not in sys.path:
        sys.path.insert(0, modules_dir)
    # 添加 shensha 目录到路径
    shensha_dir = os.path.dirname(os.path.abspath(__file__))
    if shensha_dir not in sys.path:
        sys.path.insert(0, shensha_dir)

try:
    from .通用神煞 import CommonShenShaChecker
    from .嫁娶神煞 import MarriageShenShaChecker
    from .修造神煞 import ConstructionShenShaChecker
    from .修造神煞扩展 import ConstructionShenShaCheckerExt
    from .作灶神煞 import StoveShenShaChecker
    from .开业神煞 import OpeningShenShaChecker
    from .出行神煞 import TravelShenShaChecker
    from .安葬神煞 import BurialShenShaChecker
    from .安床神煞 import BedShenShaChecker
    from .入宅神煞 import RuZhaiShenShaChecker
    from .拆舍神煞 import DemolitionShenShaChecker
    from .动土神煞 import DiggingShenShaChecker
except ImportError:
    # 导入失败时，设置正确的导入路径
    import sys
    import os
    # 添加项目根目录到路径
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    # 添加 modules 目录到路径
    modules_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if modules_dir not in sys.path:
        sys.path.insert(0, modules_dir)
    # 添加 shensha 目录到路径
    shensha_dir = os.path.dirname(os.path.abspath(__file__))
    if shensha_dir not in sys.path:
        sys.path.insert(0, shensha_dir)
    
    # 再次尝试导入
    try:
        from 通用神煞 import CommonShenShaChecker
        from 嫁娶神煞 import MarriageShenShaChecker
        from 修造神煞 import ConstructionShenShaChecker
        from 修造神煞扩展 import ConstructionShenShaCheckerExt
        from 作灶神煞 import StoveShenShaChecker
        from 开业神煞 import OpeningShenShaChecker
        from 出行神煞 import TravelShenShaChecker
        from 安葬神煞 import BurialShenShaChecker
        from 安床神煞 import BedShenShaChecker
        from 入宅神煞 import RuZhaiShenShaChecker
        from 拆舍神煞 import DemolitionShenShaChecker
        from 动土神煞 import DiggingShenShaChecker
    except ImportError as e:
        print(f"导入神煞模块失败: {e}")
        # 如果仍然失败，使用空实现
        class CommonShenShaChecker:
            pass
        class MarriageShenShaChecker:
            pass
        class ConstructionShenShaChecker:
            pass
        class StoveShenShaChecker:
            pass
        class OpeningShenShaChecker:
            pass
        class TravelShenShaChecker:
            pass
        class BurialShenShaChecker:
            pass
        class BedShenShaChecker:
            pass
        class RuZhaiShenShaChecker:
            pass
        class DemolitionShenShaChecker:
            pass
        class DiggingShenShaChecker:
            pass


def get_checker(event_type):
    """
    根据事项类型获取神煞检查器

    2026-09-16 口径统一：事项别名与检查器派发以 modules/事项标准.py
    为唯一注册表，本函数仅做转发。修造类扩展检查器
    （ConstructionShenShaCheckerExt，需坐山/主命参数）仍由评分器显式使用。

    Args:
        event_type: 事项类型

    Returns:
        ShenShaChecker: 神煞检查器实例
    """
    try:
        from ..事项标准 import get_shensha_checker as _std_get
        return _std_get(event_type)
    except Exception:
        # 极端情况下（包路径异常）回退原始派发，保证神煞检查不中断
        marriage_events = ['嫁娶', '订婚', '纳采']
        construction_events = ['修造', '装修']
        digging_events = ['动土', '破土']
        demolition_events = ['拆舍', '拆除']
        stove_events = ['作灶']
        opening_events = ['开业']
        travel_events = ['出行']
        burial_events = ['安葬']
        bed_events = ['安床']
        ruzhai_events = ['入宅', '移徙', '搬家', '迁居']

        if event_type in marriage_events:
            return MarriageShenShaChecker()
        elif event_type in construction_events:
            return ConstructionShenShaChecker()
        elif event_type in digging_events:
            return DiggingShenShaChecker()
        elif event_type in demolition_events:
            return DemolitionShenShaChecker()
        elif event_type in stove_events:
            return StoveShenShaChecker()
        elif event_type in opening_events:
            return OpeningShenShaChecker()
        elif event_type in travel_events:
            return TravelShenShaChecker()
        elif event_type in burial_events:
            return BurialShenShaChecker()
        elif event_type in bed_events:
            return BedShenShaChecker()
        elif event_type in ruzhai_events:
            return RuZhaiShenShaChecker()
        else:
            return CommonShenShaChecker()


if __name__ == '__main__':
    print("神煞模块包")
    print("使用方法: from modules.shensha import get_checker")
